#include <Arduino.h>
#include <Wire.h>
#include <ESP32Servo.h>

#define MPU_ADDR    0x68
#define SDA1        33
#define SCL1        25
#define SDA2        26
#define SCL2        27
#define SERVO1_PIN  16
#define SERVO2_PIN  17

Servo servo1, servo2;

float angle1 = 90.0f;
float angle2 = 90.0f;
uint32_t lastTime = 0;

void initMPU(TwoWire &bus) {
  bus.beginTransmission(MPU_ADDR);
  bus.write(0x6B); bus.write(0x00);
  bus.endTransmission();
  
  bus.beginTransmission(MPU_ADDR);
  bus.write(0x1B); bus.write(0x00);
  bus.endTransmission();
}

bool updateChannel(TwoWire &bus, float &angle, float dt) {
  bus.beginTransmission(MPU_ADDR);
  bus.write(0x3B);
  if (bus.endTransmission(false) != 0 || bus.requestFrom((uint8_t)MPU_ADDR, (uint8_t)14) != 14) return false;

  int16_t ay = (bus.read() << 8) | bus.read(); // skips gx
  ay = (bus.read() << 8) | bus.read();
  int16_t az = (bus.read() << 8) | bus.read();
  bus.read(); bus.read(); // this skips temp
  bus.read(); bus.read(); // skips gx
  int16_t gy = (bus.read() << 8) | bus.read();

  float ax_g = 0;
  float ay_f = ay / 16384.0f;
  float az_f = az / 16384.0f;

  float accelAngle = atan2f(ay_f, az_f) * 180.0f / PI;

  float gyroRate = gy / 131.0f;

  angle = 0.996f * (angle + gyroRate * dt) + 0.004f * accelAngle; // add alpha sep var
  return true;
}

void setup() {
  Wire.begin(SDA1, SCL1, 400000);
  Wire1.begin(SDA2, SCL2, 400000);
  
  initMPU(Wire);
  initMPU(Wire1);

  servo1.attach(SERVO1_PIN, 500, 2500);
  servo2.attach(SERVO2_PIN, 500, 2500);
  lastTime = millis();
}

void loop() {
  uint32_t now = millis();
  float dt = (now - lastTime) / 1000.0f;
  if (dt < 0.005f) return;
  lastTime = now;

  if (updateChannel(Wire, angle1, dt)) {
    servo1.write(constrain((int)(angle1 + 90.0f), 30, 160)); // more range hits model create sep var
  }
  
  if (updateChannel(Wire1, angle2, dt)) {
    servo2.write(constrain((int)(angle2 + 90.0f), 30, 160));
  }
}